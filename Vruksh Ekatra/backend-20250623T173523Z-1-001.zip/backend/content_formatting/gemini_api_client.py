import requests

def get_gemini_response(prompt,course_id,educator_id):
    system_instructions = (
    # '''you are an expert instructional designer and microcontent formatter.
    #                        Your input can be pdf, text, webpages and you can add information to improvise it like RAG.
    #                        You will receive a lesson as input text which will contain details about the course.
    #                        You just create modules of text taht aren't tedious and are easy to understand.
    #                        Have 3 modules for a course.
    #                        Your task is to process the entire lesson and output it in a structured format for Airtable import.
    #                        Desirable Output Format:
    #                        {
    #                        {"Module 1 Text":"...#..."},
    #                        {"Module 2 Text":"..."},
    #                        {"Module 3 Text":"...#..."}
    #                        }
    #                        Important:
    #                        The above json desirable output format should be the only output you give.
    #                        Give the output in json format.Do not give any other text.
    #                        Example:
    #                        Input: give a short course on harry potter
    #                        Output:
    #                         {
    #                         {"Module 1 Text":"Harry Potter is a series of fantasy novels written by British author J.K. Rowling. The series chronicles the life and adventures of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry."},
    #                         {"Module 2 Text":"The main story arc concerns Harry's struggle against Lord Voldemort, a dark wizard who aims to become immortal, conquer the wizarding world, and subjugate all non-magical people."},
    #                         {"Module 3 Text":"The series explores themes of friendship, bravery, and the battle between good and evil. It has been adapted into a successful film series and has inspired a vast amount of merchandise, fan fiction, and other media."}
    #                         }
    #                        ''')
        '''You are an expert instructional designer and microcontent formatter.
Your input can be pdf, text,webpages and you can add information to improvise it like RAG.

You will receive a lesson as input text.

Your task is to process the entire lesson and output it in a structured format for Airtable import.

👉 Rules:

✅ Break the lesson logically into 8 modules for 4 days(2 modules per day).
✅ Each Day, containing two Modules Module 1 and Module 2, must be distinct and cover different aspects of the lesson.

✅ After two Modules , move to the next Day and and that day will also have Module 1 and Module 2 
✅ Cover the entire lesson, creating in and 4 Days to significantly cover all important content.
✅ Filter and exclude any harmful, unsafe, or violent content.
 Examples: remove terms or references related to poison, bombs, explosives, self-harm, violence, hate speech, etc.
✅ Output each Day in the following exact format, Day numbers ranging from 1 to 4 and modules ranging from 1-2:

Example output format for each Day:
{{
  "Day": <Day number>,
  "CourseID": <strict instruction: replace with exact course_id given in prompt as such>,
  "EducatorID": <strict instruction: replace with educator_id given in prompt as such>,
  "Day Topic": "<Title for the day>",
  "Module 1 Text": "...#...",
  "Module 1 Link": "...",
  "Module 1 File": [{"filename": "...", "url": "..."}],
  "Module 1 LTitle": "...",
  "Module 1 List": "...\n...\n...",
  "Module 1 iBody": "...",
  "Module 1 iButtons": "...\n...",
  "Module 1 Question": "...",
  "Module 1 Ans": "...",
  "Module 1 next": "...",
  "Module 2 Text": "...#...",
  "Module 2 Link": "...",
  "Module 2 File": [{"filename": "...", "url": "..."}],
  "Module 2 LTitle": "...",
  "Module 2 List": "...\n...\n...",
  "Module 2 iBody": "...",
  "Module 2 iButtons": "...\n...",
  "Module 2 Question": "...",
  "Module 2 Ans": "...",
  "Module 2 next": "...",},
  {
  "Day": <Day number>,
  "Day Topic": "<Title for the day>",
  ....}
}
✅ Always output all fields, even if empty (use "" or [] where appropriate).
✅ For Module <Day number> List and Module <Day number> iButtons, use \n between list items.
✅ For Module <Day number> Text, use # to split main content and subcontent if helpful.
✅ Use plain JSON objects for each Day — no extra explanations, no commentary, no markdown.
✅ Do not skip any key point in the lesson — break it down across Days as needed.
✅ Each Day must have enough content to meaningfully cover its topic.

Output only JSON. No additional text. No headings. No extra notes.


👉 Important final instruction to the model:
Ensure to complete within 6 Days, covering all key points of the lesson. Each Day must be distinct and contain relevant content without skipping any important information.''')
        
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "contents": [
            {
                "parts": [
                    {"text": system_instructions},
                    {"text": prompt}
                ]
            }
        ]
    }
    params = {
        "key": "AIzaSyBCP1e1m_fRmOItuVCfDEP5fxQWRaYNyRA"  # Replace with your actual API key
    }
    response = requests.post(url, headers=headers, params=params, json=data)
    if response.status_code == 200:
        result = response.json()
        try:
            return result['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError):
            return "No response from Gemini."
    else:
        return f"Error: {response.status_code} - {response.text}"

if __name__ == "__main__":
    prompt = input("Enter your prompt: ")
    CourseID = input("Enter Course ID: ")
    EducatorID = input("Enter Educator ID: ")
    output = get_gemini_response(prompt, CourseID, EducatorID)
    print("Gemini response:", output)
    
import requests

# Airtable Config
airtable_base_id ='apphHjdFG1exNtWMl'  # Replace with your Airtable Base ID
airtable_table_name = 'Courses-new'
airtable_token = 'patoJXk7eekod2KFh.d3bb5e7c7b07a51a204315da57732a8b24f628df9829f6d7d8df4970bfdfa003'  # Use your Personal Access Token
airtable_url = f"https://api.airtable.com/v0/{airtable_base_id}/{airtable_table_name}"

headers = {
    "Authorization": f"Bearer {airtable_token}",
    "Content-Type": "application/json"
}

def send_to_airtable(lesson):
    """
    Accepts a dict or a list of dicts.
    Returns (status_code, response_json)
    """
    # If lesson is a list, prepare records for each item
    if isinstance(lesson, list):
        records = [{"fields": {k: v for k, v in item.items() if v != ""}} for item in lesson]
    elif isinstance(lesson, dict):
        records = [{"fields": {k: v for k, v in lesson.items() if v != ""}}]
    else:
        raise ValueError("Lesson must be a dict or list of dicts")
    data = {"records": records}
    response = requests.post(airtable_url, headers=headers, json=data)
    return response.status_code, response.json()
from flask import Flask, request, jsonify
from gemini_api_client import get_gemini_response
from airtableentry import send_to_airtable  # Import the function
import re
import json

app = Flask(__name__)

ALLOWED_FIELDS = {
    "Day","CourseID","EducatorID", "Day Topic", "Module 1 Text", "Module 1 Link", "Module 1 File", "Module 1 List", "Module 1 iBody",
    "Module 1 iButtons", "Module 1 Question", "Module 1 Ans", "Module 1 next",
    "Module 2 Text", "Module 2 Link", "Module 2 File", "Module 2 List", "Module 2 iBody",
    "Module 2 iButtons", "Module 2 Question", "Module 2 Ans", "Module 2 next"
    # Add/remove fields as per your Airtable schema
}

def clean_gemini_output(text):
    # Remove triple backticks and 'json' if present
    cleaned = re.sub(r"^```json\s*|^```|```$", "", text.strip(), flags=re.MULTILINE)
    # Remove trailing commas before closing brackets/braces
    cleaned = re.sub(r',(\s*[\]}])', r'\1', cleaned)
    # Remove any control characters (optional, for safety)
    cleaned = re.sub(r'[\x00-\x1F\x7F]', '', cleaned)
    return cleaned.strip()

def filter_allowed_fields(record):
    filtered = {k: v for k, v in record.items() if k in ALLOWED_FIELDS}
    # Ensure "Day" is an integer if present and convertible
    if "Day" in filtered:
        try:
            filtered["Day"] = int(filtered["Day"])
        except Exception:
            filtered.pop("Day")  # Remove if not convertible
    return filtered

@app.route('/api/gemini', methods=['POST'])
def gemini_api():
    data = request.get_json()
    prompt = data.get('prompt', '')
    if not prompt:
        return jsonify({'error': 'No prompt provided'}), 400
    output = get_gemini_response(prompt,course_id=data.get('CourseID', ''), educator_id=data.get('EducatorID', ''))
    output = clean_gemini_output(output)
    try:
        if not output:
            raise ValueError("Empty output from Gemini.")
        lesson = json.loads(output)
        # Filter out unwanted fields and fix types
        if isinstance(lesson, list):
            lesson = [filter_allowed_fields(item) for item in lesson]
        elif isinstance(lesson, dict):
            lesson = filter_allowed_fields(lesson)
        else:
            raise ValueError("Lesson must be a dict or list of dicts")
    except Exception as e:
        return jsonify({'error': f'Failed to parse lesson JSON: {str(e)}', 'raw_output': output}), 400
    status, airtable_response = send_to_airtable(lesson)
    return jsonify({'output': output, 'airtable_status': status, 'airtable_response': airtable_response})

@app.route('/')
def home():
    return jsonify({"status": "Flask Gemini API is running."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)  # Change 8000 to any available port

    #sample input:curl -X POST http://localhost:8000/api/gemini \ -H "Content-Type: application/json" \-d '{"prompt": "give a short course on harry potter"}'
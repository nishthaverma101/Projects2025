const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const { base } = require('../config/airtable');
const axios = require('axios');

// Configure multer for file upload
const upload = multer({ dest: 'uploads/' });

// Create a new course
router.post('/course', async (req, res) => {
    try {
        const { moduleText } = req.body;
        // console.log(req.body);
        const response = await axios.post('http://127.0.0.1:8000/api/gemini', {
            prompt: moduleText,
            courseName: 'c123',
            educatorId: 'e123'
        });
        // console.log(moduleText);
        // console.log(JSON.parse(response.data.output.slice(9,-7)));
        // let output = response.data.output;

    // ✅ Step 1: Remove starting ```json\n and ending ```
    // if (output.startsWith('```json\n')) {
    //   output = output.slice(8); // Remove the first 8 chars: ```json\n
    // }

    // if (output.endsWith('```')) {
    //   output = output.slice(0, -3); // Remove the last 3 chars: ```
    // }

    // ✅ Step 2: Parse the cleaned string into JSON
    // const modules = JSON.parse(output);
    // req.send(output)
        //   let rawOutput = response.data.output;
        //   rawOutput = rawOutput.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        //   const modules = JSON.parse(response.data.output.slice(7,-3))
        //   console.log(modules);
        // Create course in the Courses table - removed 'fields' wrapper
        // const courseRecord = await base('Courses').create({
        //     Name: courseName,
        //     EducatorId: educatorId || 'default',
        //     Status: 'active',
        //     Day: 1,
        //     Module_1_Text: module1Text || '',
        //     Module_1_Link: 'https://example.com',  // Hardcoded
        //     Module_2_Text: 
        //     // Module_1_File: 'sample.pdf',  // Hardcoded
        //     // Module_1_LTitle: 'Sample Title',  // Hardcoded
        //     // Module_1_List: JSON.stringify(['item1', 'item2']),  // Hardcoded
        //     // Module_1_iBody: 'Sample interactive body',  // Hardcoded
        //     // Module_1_iButtons: JSON.stringify(['Yes', 'No']),  // Hardcoded
        //     // Module_1_Question: 'Sample question?',  // Hardcoded
        //     // Module_1_Ans: 'Sample answer',  // Hardcoded
        //     // Module_1_next: '2'  // Hardcoded
        // });

        // res.status(201).json({
        //     message: 'Course created successfully',
        //     course: courseRecord
        // });
        res.send("got it")
    } catch (error) {
        console.error('Error creating course:', error);
        res.status(500).json({ error: error.message });
    }
});

// Update course content
router.post('/course/:courseId/module', async (req, res) => {
    try {
        const { courseId } = req.params;
        const { module1Text } = req.body;

        // Update the course with module data - removed fields wrapper
        const record = await base('Courses').update(courseId, {
            Module_1_Text: module1Text || ''
            // All other fields remain unchanged
        });

        res.status(200).json(record);
    } catch (error) {
        console.error('Error updating course:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get all courses
router.get('/courses', async (req, res) => {
    try {
        const records = await base('Courses').select({
            view: 'Grid view'
        }).all();

        const courses = records.map(record => ({
            id: record.id,
            name: record.get('Name'),
            educatorId: record.get('EducatorId'),
            status: record.get('Status'),
            day: record.get('Day'),
            module: {
                text: record.get('Module_1_Text'),
                link: record.get('Module_1_Link'),
                file: record.get('Module_1_File'),
                lTitle: record.get('Module_1_LTitle'),
                list: record.get('Module_1_List'),
                iBody: record.get('Module_1_iBody'),
                iButtons: record.get('Module_1_iButtons'),
                question: record.get('Module_1_Question'),
                ans: record.get('Module_1_Ans'),
                next: record.get('Module_1_next')
            }
        }));

        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get a specific course
router.get('/course/:courseId', async (req, res) => {
    try {
        const { courseId } = req.params;
        const record = await base('Courses').find(courseId);

        const course = {
            id: record.id,
            name: record.get('Name'),
            educatorId: record.get('EducatorId'),
            status: record.get('Status'),
            day: record.get('Day'),
            module: {
                text: record.get('Module_1_Text'),
                link: record.get('Module_1_Link'),
                file: record.get('Module_1_File'),
                lTitle: record.get('Module_1_LTitle'),
                list: record.get('Module_1_List'),
                iBody: record.get('Module_1_iBody'),
                iButtons: record.get('Module_1_iButtons'),
                question: record.get('Module_1_Question'),
                ans: record.get('Module_1_Ans'),
                next: record.get('Module_1_next')
            }
        };

        res.json(course);
    } catch (error) {
        console.error('Error fetching course:', error);
        res.status(500).json({ error: error.message });
    }
});

// Upload students
router.post('/course/:courseId/students', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }

    try {
        const { courseId } = req.params;
        const results = [];
        
        // Get course name
        const course = await base('Courses').find(courseId);
        const courseName = course.get('Name');

        // Process CSV
        fs.createReadStream(req.file.path)
            .pipe(csv())
            .on('data', (data) => results.push(data))
            .on('end', async () => {
                try {
                    // Add students to the Students table
                    for (const student of results) {
                        await base('Students').create({
                            fields: {
                                Name: student.Name,
                                Phone: student.Phone,
                                CourseId: courseId,
                                CourseName: courseName,
                                Next_Day: 1,
                                Day_Completed: 0,
                                Next_Module: 1,
                                Module_Completed: 0,
                                Last_Msg: '',
                                Question_Responses: '',
                                Interactive_Responses: '',
                                Responses: '',
                                Feedback: ''
                            }
                        });
                    }

                    // Delete the temporary file
                    fs.unlinkSync(req.file.path);
                    
                    res.json({ 
                        message: 'Students uploaded successfully',
                        count: results.length 
                    });
                } catch (error) {
                    console.error('Error processing students:', error);
                    res.status(500).json({ error: error.message });
                }
            });
    } catch (error) {
        console.error('Error uploading students:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;